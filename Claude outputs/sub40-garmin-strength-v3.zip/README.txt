Sub-40 plan - Garmin strength workouts, v3 (7 files)

What changed: the seated soleus raise is replaced by a standing single-leg
bent-knee calf raise ("Weighted Single-leg Bent Knee Calf Raise" in Garmin),
which only needs a step and a dumbbell.

These 7 files have the same internal IDs as your v2 versions, so the watch
should replace the old workouts instead of adding new ones.
Race week and Calf ISO did not change: keep the ones already on the watch.

Loading (OpenMTP, Garmin Express fully quit)
  1. Copy the 7 .fit files into GARMIN/NewFiles.
  2. Unplug and check the Workouts list.
  3. If any workout now appears twice, delete the older copy on the watch.
